# chatmaild

chatmaild provides dovecot autentication
to create dovecot users on login
and mail filtering.
